export interface Artykul{
    id: number;
    nazwa: string;
    opis: string;
    cena: number;
}