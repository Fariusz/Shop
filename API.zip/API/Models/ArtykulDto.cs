﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Models
{
    public class ArtykulDto
    {
       public int id { get; set; }
        public string nazwa { get; set; }
        public string opis { get; set; }
        public int cena { get; set; }
    }
}

