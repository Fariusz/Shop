﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Models
{
    public class StronnicowanieDto
    {
        public int Strona { get; set; }
        public int Ilosc { get; set; }
    }
}
